#program to convert height in feet and inches to cm
f=int(input("Enter number of feet :"))
i=float(input("Enter the number of inches : "))
f1=12*2.5*f
i1=2.5*i
cm=f1+i1
print(" Height in cm :",cm)
