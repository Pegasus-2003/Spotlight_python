# program to convert distance in feet to inches, yards and miles
f=float(input("Enter the number of feet :"))
i=f*12
y=f/3
m=f/5280
print(i,"inches",y,"yards",m,"miles")
