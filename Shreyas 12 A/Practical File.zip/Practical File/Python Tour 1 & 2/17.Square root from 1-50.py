#PROGRAM TO PRINT THE SQUARE ROOT OF NOS FROM 1 TO 50
for i in range(1,51):
    print(i**0.5)
