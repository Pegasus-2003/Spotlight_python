#PROGRAM TO CONVERT SECONDS TO MINUTES AND SECONDS
n=int(input("Enter number of seconds : "))
m=n//60
s=n%60
print(m,"minutes",s,"seconds")


