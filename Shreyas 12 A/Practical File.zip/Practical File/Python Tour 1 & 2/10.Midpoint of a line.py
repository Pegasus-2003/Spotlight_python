#program to find the mid point of a line
x1=int(input("Enter the x coordinate of the 1st point "))
y1=int(input("Enter the y coordinate of the 1st point "))
x2=int(input("Enter the x coordinate of the 2nd point "))
y2=int(input("Enter the y coordinate of the 2nd point "))
x=(x1+x2)/2
y=(y1+y2)/2
print(x,",",y,"is the midpoint")


