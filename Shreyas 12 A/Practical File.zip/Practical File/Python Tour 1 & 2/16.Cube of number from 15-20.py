#PROGRAM TO PRINT THE CUBE OF NUMBERS FROM 15 TO 20
for i in range (15,21):
    print(i*i*i)
