#to get the 3rd side of a right angles triangle from the given two sides
n1=int(input("Enter the 1st side  :"))
n2=int(input("Enter the 2nd side  :"))
n3=(n1**2+n2**2)**0.5
print(n3)
