#program to find the distance between 2 point
x1=int(input("Enter the x coordinate of the 1st point "))
y1=int(input("Enter the y coordinate of the 1st point "))
x2=int(input("Enter the x coordinate of the 2nd point "))
y2=int(input("Enter the y coordinate of the 2nd point "))
distance=((x1-x2)**2+(y1-y2)**2)**0.5
print(distance)

