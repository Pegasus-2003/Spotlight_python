#program to find area and circumference of the circle of given diamter
dia=int(input("Enter the diameter "))
r=dia/2
a=3.14*r*r
c=2*3.14*r
print("Area =",a,"; Circumference =",c)
