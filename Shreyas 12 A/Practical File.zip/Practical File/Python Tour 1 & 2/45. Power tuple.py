#Power tuple
for n in range(5):
    x=int(input("Enter number :"))
    t=(x,x**2,x**3,x**4)
    print(x,"raised to power 1,2,3,4 :=",t)
    
