import csv
with open('14th.csv','w') as file:
    writer=csv.writer(file)
    words=[['clay','banana','train'],['apple','sand','pencil'],['check','banana','train']]