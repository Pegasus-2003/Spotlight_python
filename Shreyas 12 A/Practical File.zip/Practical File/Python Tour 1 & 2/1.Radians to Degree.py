#Program to input an angle in radians and display it in degrees
r=float(input("Enter the angle in radians :"))
d=(180/3.14)*r
print(d,"Degrees")
