# program to convert all units of time to seconds
n=int(input("Enter the number : "))
s=n
m=n*60
h=n*60*60
d=n*60*60*24
print(n,"seconds ---->",s,"seconds")
print(n,"minutes ---->",m,"seconds")
print(n,"hours ---->",h,"seconds")
print(n,"days ——>",d,"seconds")
